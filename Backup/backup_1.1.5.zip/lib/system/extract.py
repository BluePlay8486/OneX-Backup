# extract.py
import zipfile
import os
import shutil
import xbmc
import xbmcvfs
import six

LOGINFO = xbmc.LOGNOTICE if six.PY2 else xbmc.LOGINFO

def extract_zip(zip_path, extract_to):
    try:
        if not xbmcvfs.exists(zip_path):
            xbmc.log(f"[OneX Extractor] ERRO: ZIP não encontrado em {zip_path}", xbmc.LOGERROR)
            return False

        xbmc.log(f"[OneX Extractor] Iniciando extração de: {zip_path}", LOGINFO)

        # Garante que o diretório de destino exista
        if not xbmcvfs.exists(extract_to):
            xbmcvfs.mkdirs(extract_to)

        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            for member in zip_ref.namelist():
                target_path = os.path.join(extract_to, member)

                # Verifica e cria pastas
                if member.endswith('/'):
                    if not xbmcvfs.exists(target_path):
                        xbmcvfs.mkdirs(target_path)
                    continue

                parent_dir = os.path.dirname(target_path)
                if not xbmcvfs.exists(parent_dir):
                    xbmcvfs.mkdirs(parent_dir)

                # Copia arquivo com segurança
                with zip_ref.open(member) as source, xbmcvfs.File(target_path, 'w+b') as target:
                    shutil.copyfileobj(source, target)

        xbmc.log("[OneX Extractor] Extração concluída com sucesso.", LOGINFO)
        return True

    except Exception as e:
        xbmc.log(f"[OneX Extractor] ERRO ao extrair: {str(e)}", xbmc.LOGERROR)
        return False