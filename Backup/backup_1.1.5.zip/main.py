import urllib.parse
# -*- coding: utf-8 -*-

import sys
import requests
import re
import os
import xbmc
import xbmcplugin
from lib.utils import route, run
from six.moves import urllib_request
import xml.etree.ElementTree as ET
from distutils.version import LooseVersion
import xbmcgui
import xbmcaddon
import shutil
import xbmcvfs
import sqlite3
import base64
from lib.system.downloader import download
from lib.system.extract import extract_zip
from urllib.parse import quote_plus, unquote_plus, urlparse, parse_qs
try:
    import json
except:
    import simplejson as json
    
ADDON_ID = 'plugin.video.OneX.Matrix'    
icon_candidate = xbmcvfs.translatePath(f'special://home/addons/{ADDON_ID}/icon.png')
ICON_PATH = icon_candidate if xbmcvfs.exists(icon_candidate) else ""

GITHUB_TOKEN = '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'
REPO_OWNER = 'BluePlay8486'
REPO_NAME = 'OneX-Backup'
BACKUP_FOLDER = 'Backup'    
    
nome_contador = "OneX-1.1.5.Matrix"
link_contador = "https://whos.amung.us/pingjs/?k=6gjsucgcje"
db_host = 'https://raw.githubusercontent.com/zoreu/base_onex/main/base.txt'

addon_handle = int(sys.argv[1])
addon = xbmcaddon.Addon()
addonname = addon.getAddonInfo('name')
icon = addon.getAddonInfo('icon')
addon_version = addon.getAddonInfo('version')
profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
home = xbmcvfs.translatePath(addon.getAddonInfo('path'))
fanart_default = os.path.join(home, 'fanart.jpg')
favorites = os.path.join(profile, 'favorites.dat')

if os.path.exists(favorites)==True:
    FAV = open(favorites).read()
else:
    FAV = []

def notify(message, name=None, iconimage=None, timeShown=5000):
    # Usa valores padrão se não forem fornecidos
    default_name = name or addonname
    default_icon = iconimage or icon

    # Escapa aspas simples e garante que todos os parâmetros sejam string
    def esc(text):
        return str(text).replace("'", "\\'") if text else ''

    cmd = "Notification('{}', '{}', {}, '{}')".format(
        esc(default_name),
        esc(message),
        timeShown,
        esc(default_icon)
    )
    xbmc.executebuiltin(cmd)

def database_update(url):
    try:
        os.mkdir(profile)
    except:
        pass
    try:
        import ntpath
        r = requests.get(url, allow_redirects=True, headers={"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36"})
        r.encoding = 'utf-8'
        data = r.text
        link = re.compile('url="(.*?)"', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)[0]
        filename = ntpath.basename(link)
        # r=root, d=directories, f = files
        myfile = []
        for r, d, f in os.walk(profile):
            for file in f:
                if file.endswith(".db"):
                    myfile.append(os.path.join(r, file))
        if not filename in str(myfile):
            for r, d, f in os.walk(profile):
                for file in f:
                    if file.endswith(".db"):
                        try:
                            os.remove(os.path.join(r, file))
                        except:
                            pass
            from lib import downloader
            dest = os.path.join(profile, filename)
            downloader.download(link, 'dados', dest)            
    except:
        pass
        
def database_clear():
    for r, d, f in os.walk(profile):
        for file in f:
            if file.endswith(".db"):
                try:
                    os.remove(os.path.join(r, file))
                except:
                    pass
    
       
def conection_sqlite(sql):
    try:
        db_list = []
        for r, d, f in os.walk(profile):
            for file in f:
                if file.endswith(".db"):
                    db_list.append(os.path.join(r, file))        
        db = db_list[0]
        conn = sqlite3.connect(db)
        cursor = conn.cursor()
        cursor.execute(sql)
        rows = cursor.fetchall()
        conn.close
        return rows
    except:
        rows = []
        return rows        
        

@route('/principal')
def principal():
    addon = xbmcaddon.Addon()
    addon_id = addon.getAddonInfo('id')
    fanart = addon.getAddonInfo('fanart')
    resources_path = os.path.join(home, 'resources', 'media')

    addDir('[B]PESQUISAR[/B]', '', 6, '',
           os.path.join(resources_path, 'pesquisar.png'), fanart,
           'PESQUISE POR FILMES, SÉRIES, ANIMES OU NOVELAS', '', '')

    context_menu_lista = [
        ('Limpar Minha Lista', f'RunPlugin(plugin://{addon_id}/?rota=16)')
    ]
    addDir('[B]MINHA LISTA[/B]', '', 15, '',
           os.path.join(resources_path, 'minha_lista.png'), fanart,
           'CLIQUE PARA VER SUA LISTA — SEGURE PARA LIMPAR OU ADICIONAR ITENS', '', '',
           contextmenu=context_menu_lista)

    addDir('[B]TV AO VIVO[/B]', '', 30, '',
           os.path.join(resources_path, 'tv_ao_vivo.png'), fanart,
           'ACESSE CANAIS GRATUITOS VIA IPTV', '', '')

    addDir('[B]FILMES[/B]', '', 1, '',
           os.path.join(resources_path, 'filmes.png'), fanart,
           '', '', '')

    addDir('[B]SÉRIES[/B]', '', 3, '',
           os.path.join(resources_path, 'series.png'), fanart,
           '', '', '')

    addDir('[B]ANIMES[/B]', '', 7, '',
           os.path.join(resources_path, 'animes.png'), fanart,
           '', '', '')

    addDir('[B]NOVELAS[/B]', '', 10, '',
           os.path.join(resources_path, 'novelas.png'), fanart,
           '', '', '')

    addDir('[B]RÁDIOS[/B]', '', 17, '',
           os.path.join(resources_path, 'radios.png'), fanart,
           '', '', '')

    addDir('[B]DOAÇÃO[/B]', 'doar', 1010, '',
       os.path.join(resources_path, 'donate.png'), fanart,
       'APOIE O PROJETO', '', '',
       play=False, folder=False)
       
    addDir('[B]ATUALIZAR ADDON[/B]', '', 998, '',
       os.path.join(resources_path, 'update.png'), fanart,
       'ATUALIZE O ADDON AUTOMATICAMENTE COM BACKUP NO GITHUB', '', '',
       play=False, folder=False)   

    addDir('[B]VERIFICAR E ATUALIZAR CONTEÚDOS[/B]', '', 18, '',
           os.path.join(resources_path, 'atualizar.png'), fanart,
           '', '', '')

    SetView('WideList')
    xbmcplugin.endOfDirectory(addon_handle)
    
@route('/tv_ao_vivo')
def tv_ao_vivo(params):
    menu_live()

def menu_live():
    resources_path = os.path.join(home, 'resources', 'media')

    items = [
        {
            'titulo': '[B][COLOR aquamarine]OPÇÃO 1:[/COLOR] [COLOR white]LISTA IPTV[/COLOR][/B]',
            'action': 'tvgratis',
            'mode': 22,
            'thumb': os.path.join(resources_path, 'iptv.png'),
            'fanart': os.path.join(resources_path, 'iptv1_fanart.jpg'),
            'descricao': 'Listas Xtream gratuitas e atualizadas',
            'genero': 'TV'
        },
        {
            'titulo': '[B][COLOR aquamarine]OPÇÃO 2:[/COLOR] [COLOR white]LISTA IPTV[/COLOR][/B]',
            'action': 'show_iptv_stremio',
            'mode': 24,
            'thumb': os.path.join(resources_path, 'iptv.png'),
            'fanart': os.path.join(resources_path, 'iptv1_fanart.jpg'),
            'descricao': 'Listas IPTV via Stremio em tempo real',
            'genero': 'TV'
        },
        {
            'titulo': '[B][COLOR aquamarine]OPÇÃO 3:[/COLOR] [COLOR white]PLUTO TV[/COLOR][/B]',
            'action': '',
            'mode': 31,
            'thumb': os.path.join(resources_path, 'plutotv.png'),
            'fanart': os.path.join(resources_path, 'iptv1_fanart.jpg'),
            'descricao': 'Canais oficiais e gratuitos do Pluto TV',
            'genero': 'TV'
        }
    ]

    for item in items:
        addDir(
            name=item['titulo'],
            url=item['action'],
            rota=item['mode'],
            subtitle='',
            iconimage=item['thumb'],
            fanart=item['fanart'],
            description=item['descricao'],
            cat=item['genero'],
            season='',
            play=False,
            folder=True,
            favorite=False
        )

    xbmcplugin.endOfDirectory(addon_handle)
    
@route('/atualizar_onex')
def atualizar_onex(params):
    verificar_versao_e_atualizar()


def get_local_version():
    try:
        path = xbmcvfs.translatePath(f'special://home/addons/{ADDON_ID}/addon.xml')
        if not xbmcvfs.exists(path):
            xbmc.log(f"[{ADDON_ID}] ERRO: addon.xml não encontrado!", xbmc.LOGERROR)
            return None

        with xbmcvfs.File(path) as f:
            content = f.read()
            if isinstance(content, bytes):
                content = content.decode('utf-8')

        root = ET.fromstring(content)
        versao = root.attrib.get('version')
        xbmc.log(f"[{ADDON_ID}] Versão local detectada: {versao}", xbmc.LOGINFO)
        return versao

    except Exception as e:
        xbmc.log(f"[{ADDON_ID}] ERRO ao ler versão local: {str(e)}", xbmc.LOGERROR)
        return None


def get_online_version():
    try:
        url = "https://raw.githubusercontent.com/BluePlay8486/Atualiza-o-BluePlay/main/version.txt"
        response = urllib_request.urlopen(url)
        return response.read().decode('utf-8').strip()
    except Exception as e:
        xbmc.log(f"[{ADDON_ID}] Falha ao obter versão online: {e}", xbmc.LOGERROR)
        return None


def verificar_versao_e_atualizar():  
    addon = xbmcaddon.Addon()  
    icon = addon.getAddonInfo('icon')  
  
    try:  
        local_version = get_local_version()  
        online_version = get_online_version()  
  
        xbmc.log(f"[{ADDON_ID}] Versão local detectada: {local_version}", xbmc.LOGINFO)  
        xbmc.log(f"[{ADDON_ID}] Versão online disponível: {online_version}", xbmc.LOGINFO)  
  
        if not local_version:  
            notify('Não foi possível ler a versão local.', 'OneX - Erro', icon)  
            return  
  
        if not online_version:  
            notify('Não foi possível obter a versão online.', 'OneX - Erro', icon)  
            return  
  
        if LooseVersion(online_version) > LooseVersion(local_version):  
            ok = xbmcgui.Dialog().yesno(
                'Atualização disponível',
                f'Versão atual: {local_version}\nNova versão: {online_version}\nDeseja atualizar agora?',
                'Cancelar',
                'Atualizar'
            )
            if ok:  
                baixar_arquivo(icon)  
            else:  
                notify('Atualização cancelada.', 'OneX', icon)  
        else:  
            notify('Você já está na última versão!', 'OneX', icon)  
  
    except Exception as e:  
        xbmc.log(f'[OneX Update] Erro inesperado: {e}', xbmc.LOGERROR)  
        notify(f'Erro inesperado: {str(e)}', 'Erro', icon)


def baixar_arquivo(icon):
    try:
        zip_url = "https://github.com/BluePlay8486/Atualizacao-OneX/raw/refs/heads/main/plugin.video.OneX.Matrix.zip"
        zip_destino = f"special://home/addons/packages/{ADDON_ID}.zip"
        destino_convertido = xbmcvfs.translatePath(zip_destino)
        addons_folder = xbmcvfs.translatePath('special://home/addons/')

        notify("Iniciando download da atualização...", "OneX", icon)

        # Faz download com barra de progresso
        download(zip_url, destino_convertido)

        # Faz backup da versão atual
        versao_antiga = get_local_version()
        backup_para_github(versao_antiga)

        # Remove versão antiga
        addon_path = os.path.join(addons_folder, ADDON_ID)
        if xbmcvfs.exists(addon_path):
            shutil.rmtree(addon_path)

        # Extrai o novo addon
        sucesso = extract_zip(destino_convertido, addons_folder)

        if sucesso:
            # Remove o ZIP temporário
            if xbmcvfs.exists(destino_convertido):
                xbmcvfs.delete(destino_convertido)

            xbmc.executebuiltin('UpdateLocalAddons')
            xbmc.sleep(2000)

            nova_versao = get_local_version()
            xbmcgui.Dialog().ok("OneX", f"Atualizado para versão {nova_versao} com sucesso!")
            xbmc.executebuiltin('Quit()')
        else:
            notify("Erro ao extrair atualização!", "OneX", icon)

    except Exception as e:
        xbmc.log(f"[{ADDON_ID}] ERRO geral na atualização: {str(e)}", xbmc.LOGERROR)
        notify(f"Erro inesperado: {str(e)}", "Erro", icon)


def backup_para_github(versao_antiga):
    try:
        backup_name = f'backup_{versao_antiga}.zip'
        addon_path = xbmcvfs.translatePath(f'special://home/addons/{ADDON_ID}')
        temp_folder = xbmcvfs.translatePath('special://home/temp/')
        zip_path = os.path.join(temp_folder, backup_name)

        shutil.make_archive(zip_path.replace('.zip', ''), 'zip', addon_path)

        with open(zip_path, 'rb') as f:
            content = base64.b64encode(f.read()).decode('utf-8')

        url = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/contents/{BACKUP_FOLDER}/{backup_name}"

        payload = {
            "message": f"Backup da versão {versao_antiga}",
            "content": content,
            "branch": "main"
        }

        headers = {
            "Authorization": f"token {GITHUB_TOKEN}",
            "Accept": "application/vnd.github+json"
        }

        response = requests.put(url, json=payload, headers=headers)

        if response.status_code == 201:
            xbmc.log(f"[{ADDON_ID}] Backup enviado com sucesso!", xbmc.LOGINFO)
        else:
            xbmc.log(f"[{ADDON_ID}] Erro ao enviar backup: {response.status_code} - {response.text}", xbmc.LOGERROR)

    except Exception as e:
        xbmc.log(f"[{ADDON_ID}] ERRO no backup: {str(e)}", xbmc.LOGERROR)


def instalar_zip(destino):
    try:
        versao_antiga = get_local_version()
        backup_para_github(versao_antiga)

        addons_folder = xbmcvfs.translatePath('special://home/addons/')
        addon_path = os.path.join(addons_folder, ADDON_ID)

        # Remove a versão antiga do addon
        if xbmcvfs.exists(addon_path):
            shutil.rmtree(addon_path)

        # Extrai o novo addon a partir do ZIP baixado
        with zipfile.ZipFile(destino, 'r') as zip_ref:
            zip_ref.extractall(addons_folder)

        # Remove o ZIP temporário
        if xbmcvfs.exists(destino):
            xbmcvfs.delete(destino)

        # Atualiza e reinicia o Kodi
        xbmc.executebuiltin('UpdateLocalAddons')
        xbmc.sleep(2000)

        nova_versao = get_local_version()
        xbmcgui.Dialog().ok("OneX", f"Atualizado para versão {nova_versao} com sucesso!")
        xbmc.executebuiltin('Quit()')

    except Exception as e:
        xbmc.log(f"[{ADDON_ID}] ERRO na instalação: {str(e)}", xbmc.LOGERROR)
        icon = xbmcaddon.Addon().getAddonInfo('icon')
        xbmcgui.Dialog().notification('Erro', f'Erro inesperado: {str(e)}', icon, 5000)
    
def to_unicode(text, encoding='utf-8', errors='strict'):
    """Force text to unicode"""
    if isinstance(text, bytes):
        return text.decode(encoding, errors=errors)
    return text

def get_search_string(heading='', message=''):
    """Ask the user for a search string"""
    search_string = None
    keyboard = xbmc.Keyboard(message, heading)
    keyboard.doModal()
    if keyboard.isConfirmed():
        search_string = to_unicode(keyboard.getText())
    return search_string

def find():
    # 1) Escolher o tipo
    opcao = xbmcgui.Dialog().select(
        'Escolha o tipo de pesquisa',           # Título da janela
        ['Filmes', 'Séries', 'Animes', 'Novelas']
    )
    if opcao == -1:          # Cancelou
        return

    # 2) Abrir teclado para digitar o termo
    tipos  = ['Filme', 'Série', 'Anime', 'Novela']   # Só para exibição
    termo  = get_search_string(heading=f"Pesquisar por {tipos[opcao]}")
    if not termo:
        return

    # 3) Chamar apenas a função correspondente
    if   opcao == 0:  # Filmes
        pesquisar_filmes(termo)
    elif opcao == 1:  # Séries
        pesquisar_series(termo)
    elif opcao == 2:  # Animes
        pesquisar_animes(termo)
    elif opcao == 3:  # Novelas
        pesquisar_novelas(termo)

    # 4) Ajustar a visualização e finalizar
    xbmcplugin.setContent(addon_handle, 'movies')
    SetView('InfoWall')
    xbmcplugin.endOfDirectory(addon_handle)

def pesquisar(name):
    pesquisar_filmes(name)
    pesquisar_series(name)
    pesquisar_animes(name)
    pesquisar_novelas(name)
    xbmcplugin.setContent(addon_handle, 'movies')
    SetView('InfoWall')
    xbmcplugin.endOfDirectory(addon_handle) 

def open_url(url,referer=False):
    if referer:    
        headers = {
        "sec-ch-ua": '"Google Chrome";v="89", "Chromium";v="89", ";Not A Brand";v="99"',
        "sec-ch-ua-mobile": "?0",
        "Upgrade-Insecure-Requests": "1",    
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36",
        "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        "Sec-Fetch-Site": "same-origin",
        "Sec-Fetch-Rota": "navigate",
        "Sec-Fetch-Dest": "iframe",
        "Referer": referer,     
        "accept-language": "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7"
        }
    else:
        headers = {
        "sec-ch-ua": '"Google Chrome";v="89", "Chromium";v="89", ";Not A Brand";v="99"',
        "sec-ch-ua-mobile": "?0",
        "Upgrade-Insecure-Requests": "1",    
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36",
        "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        "Sec-Fetch-Site": "same-origin",
        "Sec-Fetch-Rota": "navigate",
        "Sec-Fetch-Dest": "iframe",    
        "accept-language": "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7"
        }
    try:
        r = requests.get(url, allow_redirects=True, headers=headers, verify=False)
        r.encoding = 'utf-8'
        data = r.text
        return data
    except:
        try:
            import urllib.request as urllib2
            import http.cookiejar as cookielib
            cj = cookielib.CookieJar()
            opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
            if referer:
                opener.addheaders=[('Accept-Language', 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7'),('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36'),('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9'), ('Referer', referer)]
            else:
                opener.addheaders=[('Accept-Language', 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7'),('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36'),('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9')]
            request_url = opener.open(url).read()
            data = request_url.decode('utf-8')
        except:
            data = ''
        return data 

def pegar_ano():
    data = open_url('http://datadehoje.com/')
    try:
        ano = re.compile('<p id="fecha">.+?<span>(.*?)</span>').findall(data)
        if ano !=[]:
            ano_atual = ano[0].split('de')[-1].replace(' ', '')
        else:
            from datetime import date
            data_atual = date.today()
            ano_atual = data_atual.year
    except:
        from datetime import date
        data_atual = date.today()
        ano_atual = data_atual.year        
    return ano_atual

def pesquisar_filmes(name):
    sql = "SELECT * FROM filmes WHERE search like '%"+name+"%' ORDER BY name"
    rows = conection_sqlite(sql)
    if rows !=[]:
        for grupo,cover,search,name,link,subtitle,thumbnail,fanart,info in rows:
            nome_negrito = '[B]'+name+'[/B]'
            addDir(nome_negrito.encode('utf-8', 'ignore'),link.encode('utf-8'),20,str(subtitle),str(thumbnail),str(fanart),str(info).encode('utf-8', 'ignore'),'','',favorite=True)
            

def lancamento_filmes(name):
    sql = "SELECT * FROM filmes WHERE search like '%"+name+"%' ORDER BY name"
    rows = conection_sqlite(sql)
    if rows !=[]:
        for grupo,cover,search,name,link,subtitle,thumbnail,fanart,info in rows:
            nome_negrito = '[B]'+name+'[/B]'            
            addDir(nome_negrito.encode('utf-8', 'ignore'),link.encode('utf-8'),20,str(subtitle),str(thumbnail),str(fanart),str(info).encode('utf-8', 'ignore'),'','',True,False,favorite=True)
    xbmcplugin.setContent(addon_handle, 'movies')
    SetView('InfoWall')
    xbmcplugin.endOfDirectory(addon_handle)
    

def pesquisar_series(name):
    sql = "SELECT * FROM series WHERE search like '%"+name+"%' ORDER BY category"
    rows = conection_sqlite(sql)
    if rows !=[]:
        categorias = []
        for cat,cover,search,season,main_info,episode,link,subtitle,thumbnail,fanart,episode_info in rows:
            if str(cat) not in categorias and not str(cat) == 'None':
                categorias.append(str(cat))
                nome_negrito = '[B]'+str(cat)+'[/B]'
                addDir(nome_negrito.encode('utf-8', 'ignore'),'',4,'',str(cover),'',str(main_info).encode('utf-8', 'ignore'),str(cat).encode('utf-8', 'ignore'),'',favorite=True)
    

def pesquisar_animes(name):
    sql = "SELECT * FROM animes WHERE search like '%"+name+"%' ORDER BY category"
    rows = conection_sqlite(sql)
    if rows !=[]:
        categorias = []
        for cat,cover,search,season,main_info,episode,link,subtitle,thumbnail,fanart,episode_info in rows:
            if str(cat) not in categorias and not str(cat) == 'None':
                categorias.append(str(cat))
                nome_negrito = '[B]'+str(cat)+'[/B]'
                addDir(nome_negrito.encode('utf-8', 'ignore'),'',8,'',str(cover),'',str(main_info).encode('utf-8', 'ignore'),str(cat).encode('utf-8', 'ignore'),'',favorite=True)

def pesquisar_novelas(name):
    sql = "SELECT * FROM novelas WHERE search like '%"+name+"%' ORDER BY category"
    rows = conection_sqlite(sql)
    if rows !=[]:
        categorias = []
        for cat,cover,search,season,main_info,episode,link,subtitle,thumbnail,fanart,episode_info in rows:
            if str(cat) not in categorias and not str(cat) == 'None':
                categorias.append(str(cat))
                nome_negrito = '[B]'+str(cat)+'[/B]'
                addDir(nome_negrito.encode('utf-8', 'ignore'),'',11,'',str(cover),'',str(main_info).encode('utf-8', 'ignore'),str(cat).encode('utf-8', 'ignore'),'',favorite=True)

def categorias_filmes():
    sql = 'SELECT * FROM filmes ORDER BY category'
    rows = conection_sqlite(sql)
    ano = pegar_ano()
    if rows !=[]:
        categorias = []
        lancamentos = '[B]Lançamentos '+str(ano)+'[/B]'
        addDir(lancamentos.encode('utf-8', 'ignore'),'',19,'','','','',str(ano).encode('utf-8', 'ignore'),'')
        for cat,cover,search,name,link,subtitle,thumbnail,fanart,info in rows:            
            if str(cat) not in categorias and not str(cat) == 'None':
                categorias.append(str(cat))
                nome_negrito = '[B]'+str(cat)+'[/B]'
                addDir(nome_negrito.encode('utf-8', 'ignore'),'',2,'',str(cover),'','',str(cat).encode('utf-8', 'ignore'),'')
    SetView('WideList')
    xbmcplugin.endOfDirectory(addon_handle)
    

def exibir_filmes(cat):
    sql = 'SELECT * FROM filmes ORDER BY name'
    rows = conection_sqlite(sql)
    if rows !=[]:
        for grupo,cover,search,name,link,subtitle,thumbnail,fanart,info in rows:
            if str(grupo) == cat:
                nome_negrito = '[B]'+name+'[/B]'
                addDir(nome_negrito.encode('utf-8', 'ignore'),link.encode('utf-8'),20,str(subtitle),str(thumbnail),str(fanart),str(info).encode('utf-8', 'ignore'),str(cat).encode('utf-8'),'',True,False,favorite=True)
    xbmcplugin.setContent(addon_handle, 'movies')
    SetView('InfoWall')
    xbmcplugin.endOfDirectory(addon_handle)
    
def categorias_series():
    sql = 'SELECT * FROM series ORDER BY category'
    rows = conection_sqlite(sql)
    if rows !=[]:
        categorias = []
        for cat,cover,search,season,main_info,episode,link,subtitle,thumbnail,fanart,episode_info in rows:
            if str(cat) not in categorias and not str(cat) == 'None':
                categorias.append(str(cat))
                nome_negrito = '[B]'+str(cat)+'[/B]'
                addDir(nome_negrito.encode('utf-8', 'ignore'),'',4,'',str(cover),'',str(main_info).encode('utf-8', 'ignore'),str(cat).encode('utf-8', 'ignore'),'',favorite=True)
    xbmcplugin.setContent(addon_handle, 'movies')
    SetView('InfoWall')
    xbmcplugin.endOfDirectory(addon_handle)
    
   
def categorias_animes():
    sql = 'SELECT * FROM animes ORDER BY category'
    rows = conection_sqlite(sql)
    if rows !=[]:
        categorias = []
        for cat,cover,search,season,main_info,episode,link,subtitle,thumbnail,fanart,episode_info in rows:
            if str(cat) not in categorias and not str(cat) == 'None':
                categorias.append(str(cat))
                nome_negrito = '[B]'+str(cat)+'[/B]'
                addDir(nome_negrito.encode('utf-8', 'ignore'),'',8,'',str(cover),'',str(main_info).encode('utf-8', 'ignore'),str(cat).encode('utf-8', 'ignore'),'',favorite=True)
    xbmcplugin.setContent(addon_handle, 'movies')
    SetView('InfoWall')
    xbmcplugin.endOfDirectory(addon_handle)

def categorias_novelas():
    sql = 'SELECT * FROM novelas ORDER BY category'
    rows = conection_sqlite(sql)
    if rows !=[]:
        categorias = []
        for cat,cover,search,season,main_info,episode,link,subtitle,thumbnail,fanart,episode_info in rows:
            if str(cat) not in categorias and not str(cat) == 'None':
                categorias.append(str(cat))
                nome_negrito = '[B]'+str(cat)+'[/B]'
                addDir(nome_negrito.encode('utf-8', 'ignore'),'',11,'',str(cover),'',str(main_info).encode('utf-8', 'ignore'),str(cat).encode('utf-8', 'ignore'),'',favorite=True)
    xbmcplugin.setContent(addon_handle, 'movies')
    SetView('InfoWall')
    xbmcplugin.endOfDirectory(addon_handle)     
    
def exibir_temporadas_series(cat):
    sql = 'SELECT * FROM series ORDER BY season'
    rows = conection_sqlite(sql)
    if rows !=[]:
        temporadas = []
        for grupo,cover,search,season,main_info,episode,link,subtitle,thumbnail,fanart,episode_info in rows:
            if str(grupo) == cat and str(season) not in temporadas and not str(season) == 'None':
                temporadas.append(str(season))
                nome_negrito = '[B]'+str(season)+'[/B]'
                addDir(nome_negrito.encode('utf-8', 'ignore'),'',5,'',str(cover),'',str(main_info).encode('utf-8', 'ignore'),str(cat).encode('utf-8', 'ignore'),str(season).encode('utf-8', 'ignore'))
    xbmcplugin.setContent(addon_handle, 'movies')
    SetView('InfoWall')
    xbmcplugin.endOfDirectory(addon_handle)
    
def exibir_temporadas_animes(cat):
    sql = 'SELECT * FROM animes ORDER BY season'
    rows = conection_sqlite(sql)
    if rows !=[]:
        temporadas = []
        for grupo,cover,search,season,main_info,episode,link,subtitle,thumbnail,fanart,episode_info in rows:
            if str(grupo) == cat and str(season) not in temporadas and not str(season) == 'None':
                temporadas.append(str(season))
                nome_negrito = '[B]'+str(season)+'[/B]'
                addDir(nome_negrito.encode('utf-8', 'ignore'),'',9,'',str(cover),'',str(main_info).encode('utf-8', 'ignore'),str(cat).encode('utf-8', 'ignore'),str(season).encode('utf-8', 'ignore'))
    xbmcplugin.setContent(addon_handle, 'movies')
    SetView('InfoWall')
    xbmcplugin.endOfDirectory(addon_handle)

def exibir_temporadas_novelas(cat):
    sql = 'SELECT * FROM novelas ORDER BY season'
    rows = conection_sqlite(sql)
    if rows !=[]:
        temporadas = []
        for grupo,cover,search,season,main_info,episode,link,subtitle,thumbnail,fanart,episode_info in rows:
            if str(grupo) == cat and str(season) not in temporadas and not str(season) == 'None':
                temporadas.append(str(season))
                nome_negrito = '[B]'+str(season)+'[/B]'
                addDir(nome_negrito.encode('utf-8', 'ignore'),'',12,'',str(cover),'',str(main_info).encode('utf-8', 'ignore'),str(cat).encode('utf-8', 'ignore'),str(season).encode('utf-8', 'ignore'))
    xbmcplugin.setContent(addon_handle, 'movies')
    SetView('InfoWall')
    xbmcplugin.endOfDirectory(addon_handle)    

def exibir_episodios_series(cat,season):
    sql = 'SELECT * FROM series ORDER BY episode'
    rows = conection_sqlite(sql)
    if rows !=[]:
        for grupo,cover,search,temp,main_info,episode,link,subtitle,thumbnail,fanart,episode_info in rows:
            if str(grupo) == cat and str(temp) == season and not str(temp) == 'None':
                nome_negrito = '[B]'+str(episode)+'[/B]'
                addDir(nome_negrito.encode('utf-8', 'ignore'),link.encode('utf-8'),20,str(subtitle),str(thumbnail),str(fanart),str(episode_info).encode('utf-8', 'ignore'),'','',True,False)
    xbmcplugin.setContent(addon_handle, 'movies')
    SetView('InfoWall')
    xbmcplugin.endOfDirectory(addon_handle)

def exibir_episodios_animes(cat,season):
    sql = 'SELECT * FROM animes ORDER BY episode'
    rows = conection_sqlite(sql)
    if rows !=[]:
        for grupo,cover,search,temp,main_info,episode,link,subtitle,thumbnail,fanart,episode_info in rows:
            if str(grupo) == cat and str(temp) == season and not str(temp) == 'None':
                nome_negrito = '[B]'+str(episode)+'[/B]'
                addDir(nome_negrito.encode('utf-8', 'ignore'),link.encode('utf-8'),20,str(subtitle),str(thumbnail),str(fanart),str(episode_info).encode('utf-8', 'ignore'),'','',True,False)
    xbmcplugin.setContent(addon_handle, 'movies')
    SetView('InfoWall')
    xbmcplugin.endOfDirectory(addon_handle)

def exibir_episodios_novelas(cat,season):
    sql = 'SELECT * FROM novelas ORDER BY episode'
    rows = conection_sqlite(sql)
    if rows !=[]:
        for grupo,cover,search,temp,main_info,episode,link,subtitle,thumbnail,fanart,episode_info in rows:
            if str(grupo) == cat and str(temp) == season and not str(temp) == 'None':
                nome_negrito = '[B]'+str(episode)+'[/B]'
                addDir(nome_negrito.encode('utf-8', 'ignore'),link.encode('utf-8'),20,str(subtitle),str(thumbnail),str(fanart),str(episode_info).encode('utf-8', 'ignore'),'','',True,False)
    xbmcplugin.setContent(addon_handle, 'movies')
    SetView('InfoWall')
    xbmcplugin.endOfDirectory(addon_handle)     
    
def radios():
    sql = 'SELECT * FROM radios ORDER BY name'
    rows = conection_sqlite(sql)
    if rows !=[]:
        for name,url,thumbnail,fanart,description in rows:
            addDir(name.encode('utf-8', 'ignore'),url.encode('utf-8'),20,'',str(thumbnail),str(fanart),str(description).encode('utf-8', 'ignore'),'radios','',play=True,folder=False,favorite=True)
    xbmcplugin.setContent(addon_handle, 'movies')
    SetView('InfoWall')
    xbmcplugin.endOfDirectory(addon_handle) 

def base64decode(string):
    decoded = base64.b64decode(string).decode('utf-8')
    return decoded 

def play_video(name,url,iconimage,description,subtitle,play):
    #notify('Resolvendo url...',name,iconimage)
    url_resolved = str(resolve(url))
    if url_resolved > '' and url_resolved !='None':
        if 'netcine' in url_resolved:
            url_final = url_resolved+'|Referer=https://p.netcine.biz/'
        else:
            url_final = url_resolved 
        if 'plugin://' in url_resolved:
            xbmc.executebuiltin('RunPlugin(' + url_resolved + ')')
        else:
            li = xbmcgui.ListItem(name, path=url_final)
            li.setArt({"icon": iconimage, "thumb": iconimage})
            li.setInfo(type='video', infoLabels={'Title': name, 'plot': description })
            if subtitle !='' and subtitle !=None and subtitle !='None':
                try:
                    subtitle = base64decode(subtitle)
                except:
                    pass
                li.setSubtitles([subtitle])
            if play == 'True':
                xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
            else:        
                xbmc.Player().play(item=url_final, listitem=li)
    else:
        notify('Falha ao resolver url!',name,iconimage)

  
def netcine_resolve(url,LOG=False):
    data = open_url(url, 'https://p.netcine.biz/')
    if LOG:
        try:
            f = open(xbmcvfs.translatePath(home+'/LOG-URLRESOLVE.txt'),'w')
            f.write(data)
            f.close()
        except:
            pass
    page_select = re.compile('iframe.+?src="(.+?)"', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)
    page1 = re.compile("location.href='(.+?)'", re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)
    page2 = re.compile('<div.+?class="itens">.+?<a.+?href.+?=".+?data=(.+?)"', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)
    if page_select !=[]:
        for url_iframe in page_select:
            if url_iframe.find('selec') >= 0:
                data_iframe = open_url(url_iframe, '')
                data_iframe_RE = re.compile('data=(.+?)"', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data_iframe)
                if data_iframe_RE !=[]:
                    try:
                        player = data_iframe_RE[0]
                        resolved = netcine_resolve(player)
                    except:
                        resolved = ''
                else:
                    resolved = ''
            elif url_iframe.find('camp') >= 0:
                data_iframe = open_url(url_iframe, 'https://p.netcine.biz/')
                data_iframe_RE = re.compile('data=(.+?)"', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data_iframe)
                if data_iframe_RE !=[]:
                    try:
                        player = data_iframe_RE[0]
                        resolved = netcine_resolve(player)
                    except:
                        resolved = ''
                else:
                    resolved = ''            
            else:
                data_iframe = open_url(url_iframe, 'https://p.netcine.biz/')
                data_iframe_RE = re.compile('data=(.+?)"', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data_iframe)
                if data_iframe_RE !=[]:
                    try:
                        player = data_iframe_RE[0]
                        resolved = netcine_resolve(player)
                    except:
                        resolved = ''
                else:
                    resolved = ''       
    elif page1 !=[]:
        for player_url in page1:
            if player_url.find('desktop') >= 0:
                page2 = open_url(player_url, 'https://p.netcine.biz/')
                video_url_RE = re.compile("file':'(.+?)'", re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(page2)
                if video_url_RE !=[]:
                    for video_url in video_url_RE:
                        if video_url.find('-ALTO') >= 0:
                            resolved = video_url
                        else:
                            resolved = ''
                else:
                    resolved = ''
            #else:
            #    try:
            #        resolved = urlresolve(page1[0])
            #    except:
            #        resolved = ''
    elif page2 !=[]:
        try:
            player = page2[0]
            data = open_url(player, 'https://p.netcine.biz/')
            video_url_RE = re.compile('file:.+?"(.+?)"', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)
            if video_url_RE !=[]:
                for video_url in video_url_RE:
                    if video_url.find('-ALTO') >= 0:
                        resolved = video_url
                    else:
                        resolved = ''
            else:
                resolved = ''
        except:
            resolved = '' 
    else:
        video_url_RE = re.compile("file':'(.+?)'", re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)
        if video_url_RE !=[]:
            for video_url in video_url_RE:
                if video_url.find('-ALTO') >= 0:
                    resolved = video_url
                else:
                    resolved = ''
        else:
            resolved = ''
    return resolved

#streamtape.com        
def streamtape(url):
    correct_url = url.replace('streamtape.com/v/', 'streamtape.com/e/')
    data = open_url(correct_url)
    link_part1_re = re.compile('<div.+?.+?style="display:none;">(.*?)&token=.+?</div>').findall(data)
    link_part2_re = re.compile("<script>.+?token=(.*?)'.+?</script>").findall(data)
    if link_part1_re !=[] and link_part2_re !=[]:
        part1 = link_part1_re[0]
        part2 = link_part2_re[0]
        part1 = part1.replace(' ', '')
        if 'streamtape' in part1:
            try:
                part1 = part1.split('streamtape')[1]
                final = 'streamtape' + part1 + '&token=' + part2
                link = 'https://' + final + '&stream=1|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36'
            except:
                link = ''
        elif 'get_video' in part1:
            try:
                part1_1 = part1.split('get_video')[0]
                part1_2 = part1.split('get_video')[1]
                part1_1 = part1_1.replace('/', '')
                part1 = part1_1 + '/get_video' + part1_2
                final = part1 + '&token=' + part2
                link = 'https://' + final + '&stream=1|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36'
            except:
                link = ''
        else:
            link = ''
    else:
        link = ''
    return link
    
def pandafiles(url):
    data = open_url(url)
    source = re.compile('<input class="downb" type="submit" name="method_premium".+?<a href="(.*?)">', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)
    if source:
        link = source[0]
    else:
        link = ''
    return link

#https://filmes.click/ - pegar link com index2.php ou play2.php
def filmes_click(url):
    parsed_uri = urllib.urlparse(url)
    base = '{uri.scheme}://{uri.netloc}/'.format(uri=parsed_uri)
    data = open_url(url)
    link1 = re.compile('source src="(.*?)"').findall(data)
    link2 = re.compile('media.MediaInfo.+?"(.+?)".+?,', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)
    if link1 !=[]:
        resolved = base+link1[0]
    elif link2 !=[]:
        resolved = base+link2[0]
    else:
        resolved = ''
    return resolved    

#https://megafilmeshdd.co/
def megafilmeshdd_co(url):
    data = open_url(url)
    link = re.compile('file":"(.*?)",').findall(data)
    if link !=[]:
        resolved = link[0].replace('\/', '/')
    else:
        resolved = ''
    return resolved
    
#https://superfilmes.tv/ - pegar legenda no link  
def superfilmes_tv(url):
    data = open_url(url)
    link = re.compile("mp4Id.+?=.+?'(.*?)'").findall(data)
    if link !=[]:
        resolved = link[0]+'|Referer=https://superfilmes.tv/'
        resolved = resolved.replace(' ', '')
    else:
        resolved = ''
    return resolved    

#vidyard.com - https://filmesgratiscinefilmeshd.com.br/
def vidyard_com(url):
    if not '.json' in url:
        parsed_uri = urllib.urlparse(url)
        base = '{uri.scheme}://{uri.netloc}/'.format(uri=parsed_uri)
        link = re.escape(url)
        id = re.compile(r'.com/(.*?)\\').findall(link)
        id2 = re.compile(r'.com/(.*)').findall(link)
        if id !=[]:
            api = base+'player/'+id[0]+'.json'
        elif id2 !=[]:
            api = base+'player/'+id2[0]+'.json'
        data = open_url(api)
        _720p = re.compile('"profile":"720p","url":"(.*?)","mimeType"').findall(data)
        _480p = re.compile('"profile":"480p","url":"(.*?)","mimeType"').findall(data)
        _360p = re.compile('"profile":"360p","url":"(.*?)","mimeType"').findall(data)
        if _720p !=[]:
            resolved = _720p[0]+'|Referer='+base
        elif _480p !=[]:
            resolved = _480p[0]+'|Referer='+base
        elif _360p !=[]:
            resolved = _360p[0]+'|Referer='+base
        else:
            resolved = ''
    elif '.json' in url:
        data = open_url(url)
        _720p = re.compile('"profile":"720p","url":"(.*?)","mimeType"').findall(data)
        _480p = re.compile('"profile":"480p","url":"(.*?)","mimeType"').findall(data)
        _360p = re.compile('"profile":"360p","url":"(.*?)","mimeType"').findall(data)
        if _720p !=[]:
            resolved = _720p[0]+'|Referer='+base
        elif _480p !=[]:
            resolved = _480p[0]+'|Referer='+base
        elif _360p !=[]:
            resolved = _360p[0]+'|Referer='+base
        else:
            resolved = ''
    else:
        resolved = ''
    return resolved

##https://www.mmfilmeshd.tv/
def mmfilmes_tv(url):
    if 'player.moduda.fun' in url and 'embed' in url:
        data = open_url(url,'https://www.mmfilmeshd.tv/')
        iframe = re.compile("addiframe.+?'(.*?)'").findall(data)
        if iframe !=[]:
            data2 = open_url(iframe[0],'https://player.moduda.fun/')
            source = re.compile("file':'(.*?)',").findall(data2)
            resolved = source[0]
        else:
            resolved = ''
    else:
        resolved = ''
    return resolved

#https://fshd.link/ - https://www.askflix.net/
def fsh_link(url):
    if 'fshd.link' in url and 'embed' in url:
        data = open_url(url,'https://www.receitasdahora.online/')
        source = re.compile('"file":"(.*?)",').findall(data)
        if source !=[]:
            resolved = source[0].replace('\/', '/')
        else:
            resolved = ''
    else:
        resolved = ''
    return resolved
    

def zeroflix(url):
    if 'zeroflix.org/player' in url:
        data = open_url(url)
        video = re.compile('source.+?src="(.*?)"').findall(data)
        if video !=[]:
            resolved = video[0]
        else:
            resolved = ''
    else:
        resolved = ''
    return resolved
    

def megaseriesonline(url):
    if 'playnewserie.xyz/player' in url:
        data = open_url(url)
        video = re.compile('source.+?src="(.*?)"').findall(data)
        if video !=[]:
            resolved = video[0]
        else:
            resolved = ''
    else:
        resolved = ''
    return resolved  

def suatela(url):
    if 'suatela.com/ajax/view.php?type=loading-video' in url:
        data = open_url(url,'https://suatela.com/')
        iframe = re.compile(r'date-url=.?"(.*?)\\">').findall(data)
        if iframe !=[]:
            iframe = iframe[0].replace('\/', '/')
            resolved = suatela(iframe)
        else:
            resolved = ''
    elif 'enternaimentetcgg' in url:
        data = open_url(url,'https://suatela.com/')
        try:
            video_1080p = re.compile("<input.+?id='url_download_1080p'.+?value='(.*?)'>").findall(data)[0]
            video_1080p = video_1080p
        except:
            video_1080p = ''
        try:
            video_720p = re.compile("<input.+?id='url_download_720p'.+?value='(.*?)'>").findall(data)[0]
            video_720p = video_720p
        except:
            video_720p = ''
        try:
            video_480p = re.compile("<input.+?id='url_download_480p'.+?value='(.*?)'>").findall(data)[0]
            video_480p = video_480p
        except:
            video_480p = ''
        if video_1080p > '':
            resolved = video_1080p
        elif video_720p > '':
            resolved = video_720p
        elif video_480p > '':
            resolved = video_480p
        else:
            resolved = ''
    else:
        resolved = ''
    return resolved 

def youtube(url):
    url_data = urllib.urlparse(url)
    query = urllib.parse_qs(url_data.query)
    video = query["v"][0]
    plugin = 'plugin://plugin.video.youtube/play/?video_id={}'.format(video)
    return plugin
    

def resolve(url):
    #obs: fembeed é feurl
    try:
        url = base64decode(url)
    except:
        pass
        
    try:
        if 'streamtape' in url:
            resolved = streamtape(url)
        elif 'pandafiles' in url:
            resolved = pandafiles(url)            
        elif 'filmes.click' in url and 'index2.php' in url or 'filmes.click' in url and 'play2.php' in url:
            resolved = filmes_click(url)
        elif 'filmes.click' in url and '.mp4' in url:
            resolved = url
        elif 'megafilmeshdd.co' in url:
            resolved = megafilmeshdd_co(url)
        elif 'superfilmes.tv' in url and 'share' in url:
            resolved = superfilmes_tv(url)
        #https://fornodelenha.net/
        elif 'apiblogger.xyz' in url:
            #https://apiblogger.xyz/blogger/video-play.mp4/?contentId=a15479cd9ff388a4
            resolved = url+'|Referer=https://play.midiaflixhd.com/'
        elif 'vidyard.com' in url:
            resolved = vidyard_com(url)
        elif 'player.moduda.fun' in url and 'embed' in url:
            resolved = mmfilmes_tv(url)
        elif 'fshd.link' in url and 'embed' in url:
            resolved = fsh_link(url)
        elif 'youtube.com' in url and 'watch' in url:
            resolved = youtube(url)
        elif 'netcine' in url:
            resolved = netcine_resolve(url)
        elif 'zeroflix.org/player' in url:
            resolved = zeroflix(url)
        elif 'playnewserie.xyz/player' in url:
            resolved = megaseriesonline(url)
        elif 'suatela.com/ajax/view.php?type=loading-video' in url or 'enternaimentetcgg' in url:
            resolved = suatela(url)
        elif not 'feurl' in url and not 'fembed' in url and '.mp4' in url or not 'feurl' in url and not 'fembed' in url and '.mp3' in url or not 'feurl' in url and not 'fembed' in url and '.mkv' in url or not 'feurl' in url and not 'fembed' in url and '.m3u8' in url:
            resolved = url
        else:
            try:
                from lib import resolveurl
                status = 'ok'
            except:
                status = 'error'
            if 'feurl.com' and 'api' in url:
                url = url.replace('api/source','v')
            try:
                resolved = resolveurl.resolve(url)
            except:
                resolved = 'none'
            if not 'http' in str(resolved) and not status == 'error':
                notify('Falha ao resolver, tente novamente...', 'OneX')
            elif status == 'error':
                notify('Falha ao importar resolver, tente novamente...', 'OneX')
    except:
        resolved = url
    return resolved
       

def limpar_lista():
    exists = os.path.isfile(favorites)
    if exists:
        if xbmcgui.Dialog().yesno(addonname, 'Deseja limpar minha lista?'):
            try:
                os.remove(favorites)
            except:
                pass
            xbmcgui.Dialog().ok('Sucesso', '[B][COLOR white]Minha lista limpa com sucesso![/COLOR][/B]')

def getFavorites():
    try:
        try:
            items = json.loads(open(favorites).read())
        except:
            items = ''
        total = len(items)
        if int(total) > 0:
            for i in items:
                name = i[0]
                url = i[1]
                rota = i[2]
                subtitle = i[3]
                iconimage = i[4]
                fanArt = i[5]
                description = i[6]
                cat = i[7]
                season = i[8]
                #play = i[9]
                if rota == 20:
                    play = True
                    folder= False
                else:
                    play = False
                    folder = True
                #if play == 'True':
                #    play = True
                #    folder = False
                #else:
                #    play = False
                #    folder = True
                
                addDir(name.encode('utf-8', 'ignore'),url.encode('utf-8'),rota,str(subtitle),str(iconimage),str(fanArt),str(description).encode('utf-8', 'ignore'),str(cat).encode('utf-8', 'ignore'),str(season).encode('utf-8', 'ignore'),play=play,folder=folder,favorite=True)
            xbmcplugin.setContent(addon_handle, 'movies')
            SetView('InfoWall')
            xbmcplugin.endOfDirectory(addon_handle)
        else:
            xbmcgui.Dialog().ok('[B][COLOR white]AVISO[/COLOR][/B]','Nenhuma Série ou Filme Adicionado na Minha lista')
                
    except:
        xbmcplugin.setContent(addon_handle, 'movies')
        SetView('InfoWall')
        xbmcplugin.endOfDirectory(addon_handle)

def addFavorite(name,url,rota,subtitle,iconimage,fanart,description,cat,season,play):
    favList = []
    if os.path.exists(favorites)==False:
        addonID = xbmcaddon.Addon().getAddonInfo('id')
        addon_data_path = xbmcvfs.translatePath(os.path.join('special://home/userdata/addon_data', addonID))
        if os.path.exists(addon_data_path)==False:
            os.mkdir(addon_data_path)
        xbmc.sleep(7)
        favList.append((name,url,rota,subtitle,iconimage,fanart,description,cat,season,play))
        a = open(favorites, "w")
        a.write(json.dumps(favList))
        a.close()
        notify('adicionado a Minha lista!',name,iconimage)
        #xbmc.executebuiltin("XBMC.Container.Refresh")
    else:
        a = open(favorites).read()
        data = json.loads(a)
        data.append((name,url,rota,subtitle,iconimage,fanart,description,cat,season,play))
        b = open(favorites, "w")
        b.write(json.dumps(data))
        b.close()
        notify('Adicionado a Minha lista!',name,iconimage)
        #xbmc.executebuiltin("XBMC.Container.Refresh")

def rmFavorite(name):
    data = json.loads(open(favorites).read())
    for index in range(len(data)):
        if data[index][0]==name:
            del data[index]
            b = open(favorites, "w")
            b.write(json.dumps(data))
            b.close()
            break
    notify('Removido da Minha lista!', 'OneX')
    #xbmc.executebuiltin("Container.Refresh")        
    

def addDir(name, url, rota, subtitle, iconimage, fanart,
           description, cat, season,
           play=False, folder=True, favorite=False, contextmenu=[]):

    def safe_quote(param):
        return urllib.parse.quote_plus(str(param)) if param else ""

    # Monta a URL com os parâmetros de forma segura
    u = sys.argv[0] + "?url=" + safe_quote(url) + \
        "&rota=" + safe_quote(rota) + \
        "&name=" + safe_quote(name) + \
        "&fanart=" + safe_quote(fanart) + \
        "&iconimage=" + safe_quote(iconimage) + \
        "&subtitle=" + safe_quote(subtitle) + \
        "&description=" + safe_quote(description) + \
        "&cat=" + safe_quote(cat) + \
        "&season=" + safe_quote(season) + \
        "&play=" + safe_quote(str(play))

    li = xbmcgui.ListItem(label=name)

    # Se não houver fanart, usa o padrão
    fanart_image = fanart if fanart else fanart_default

    # Define as artes corretamente
    li.setArt({
        "icon": iconimage,
        "thumb": iconimage,
        "poster": iconimage,
        "fanart": fanart_image
    })

    # Define as informações de mídia
    li.setInfo(type="Video", infoLabels={
        "title": name,
        "plot": description,
        "genre": cat,
        "season": season
    })

    li.setProperty('fanart_image', fanart_image)

    # Marca como reproduzível, se necessário
    if play:
        li.setProperty('IsPlayable', 'true')

    # Cria menu de contexto para favoritos
    try:
        contextMenu = contextmenu.copy() if contextmenu else []

        if favorite:
            if name in FAV:
                contextMenu.append((
                    'Remover da Minha Lista',
                    'RunPlugin(%s?rota=14&name=%s)' % (sys.argv[0], urllib.parse.quote_plus(name))
                ))
            else:
                fav_params = (
                    '%s?rota=13&name=%s&url=%s&subtitle=%s&iconimage=%s&fanart=%s'
                    '&description=%s&cat=%s&season=%s&play=%s&fav_mode=%s' %
                    (sys.argv[0],
                     urllib.parse.quote_plus(name),
                     urllib.parse.quote_plus(url),
                     urllib.parse.quote_plus(subtitle),
                     urllib.parse.quote_plus(iconimage),
                     urllib.parse.quote_plus(fanart),
                     urllib.parse.quote_plus(description),
                     urllib.parse.quote_plus(cat),
                     urllib.parse.quote_plus(season),
                     urllib.parse.quote_plus(str(play)),
                     str(rota))
                )
                contextMenu.append(('Adicionar à Minha Lista', 'RunPlugin(%s)' % fav_params))

        if contextMenu:
            li.addContextMenuItems(contextMenu)
    except Exception as e:
        xbmc.log(f"Erro ao criar menu de contexto: {e}", level=xbmc.LOGERROR)

    xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=li, isFolder=folder)

def contador():
    try:
        import urllib.request as urllib2
        opener = urllib2.build_opener()
        opener.addheaders=[('Accept-Language', 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7'),('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36'),('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9'), ('Referer', nome_contador)]
        data = opener.open(link_contador).read()
    except:
        pass
    
contador()   

def donate_question():
    addon = xbmcaddon.Addon()
    icon_path = addon.getAddonInfo('icon')  # Pega o ícone do addon

    dialog = xbmcgui.Dialog()
    confirmar = dialog.yesno('Doação', 'Deseja fazer uma doação ao desenvolvedor?', nolabel='NÃO', yeslabel='SIM')
    if confirmar:
        janela = Donate()
        janela.doModal()
        del janela

        xbmc.executebuiltin(f'Notification(Obrigado!,Obrigado pela doação. Aproveite o addon!,5000,{icon_path})')

class Donate(xbmcgui.WindowDialog):
    def __init__(self):
        try:
            self.image = xbmcgui.ControlImage(440, 128, 400, 400,
                os.path.join(home, 'resources', 'images', 'qrcode.png'))
            self.text = xbmcgui.ControlLabel(
                x=150, y=570, width=1100, height=25,
                label='[B][COLOR yellow]SE ESSE ADD-ON LHE AGRADA, FAÇA UMA DOAÇÃO VIA PIX ACIMA E MANTENHA ESSE SERVIÇO ATIVO[/COLOR][/B]',
                textColor='yellow')
            self.text2 = xbmcgui.ControlLabel(
                x=495, y=600, width=1000, height=25,
                label='[B][COLOR yellow]PRESSIONE VOLTAR PARA SAIR[/COLOR][/B]',
                textColor='yellow')
            self.addControl(self.image)
            self.addControl(self.text)
            self.addControl(self.text2)
        except:
            pass

def SetView(name):
    if name == 'Wall':
        try:
            xbmc.executebuiltin('Container.SetViewMode(500)')
        except:
            pass
    if name == 'List':
        try:
            xbmc.executebuiltin('Container.SetViewMode(50)')
        except:
            pass
    if name == 'Poster':
        try:
            xbmc.executebuiltin('Container.SetViewMode(51)')
        except:
            pass
    if name == 'Shift':
        try:
            xbmc.executebuiltin('Container.SetViewMode(53)')
        except:
            pass
    if name == 'InfoWall':
        try:
            xbmc.executebuiltin('Container.SetViewMode(54)')
        except:
            pass
    if name == 'WideList':
        try:
            xbmc.executebuiltin('Container.SetViewMode(55)')
        except:
            pass
    if name == 'Fanart':
        try:
            xbmc.executebuiltin('Container.SetViewMode(502)')
        except:
            pass

def get_params():
    param = {}
    paramstring = sys.argv[2]
    xbmc.log(f"[DEBUG] Params string: {paramstring}", xbmc.LOGINFO)
    
    if len(paramstring) >= 2:
        params = paramstring
        cleanedparams = params.replace('?', '')
        if params[-1] == '/':
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        for pair in pairsofparams:
            splitparams = pair.split('=')
            if len(splitparams) == 2:
                param[splitparams[0]] = splitparams[1]
    xbmc.log(f"[DEBUG] Parametros extraídos: {param}", xbmc.LOGINFO)
    return param

def main():
    params=get_params()
    url=None
    name=None
    rota=None
    iconimage=None
    fanart=None
    description=None
    subtitle=None
    cat=None
    season=None
    pesquisa=None
    fav_mode=None
    page=1
    play='False'

    try:
        url=urllib.unquote_plus(params["url"])
    except:
        pass
    try:
        name=urllib.unquote_plus(params["name"])
    except:
        pass
    try:
        iconimage=urllib.unquote_plus(params["iconimage"])
    except:
        pass
    try:
        rota=int(params["rota"])
    except:
        pass
    try:
        fanart=urllib.unquote_plus(params["fanart"])
    except:
        pass
    try:
        description=urllib.unquote_plus(params["description"])
    except:
        pass

    try:
        subtitle=urllib.unquote_plus(params["subtitle"])
    except:
        pass
    try:
        cat=urllib.unquote_plus(params["cat"])
    except:
        pass
    try:
        season=urllib.unquote_plus(params["season"])
    except:
        pass        
    try:
        pesquisa=urllib.unquote_plus(params["pesquisa"])
    except:
        pass
    try:
        play=urllib.unquote_plus(params["play"])
    except:
        pass        
    try:
        fav_mode=int(params["fav_mode"])
    except:
        pass
        
params = get_params()

try:
    rota = int(params.get("rota", 0))
except (TypeError, ValueError):
    rota = 0

path = params.get("path", "")       

if rota == 0:
    database_update(db_host)
    principal()
elif rota == 30:
    menu_live()  
elif rota == 1:
    database_update(db_host)
    categorias_filmes()
elif rota == 1010:
    donate_question()
elif rota == 998:
    xbmc.log('[OneX] Botão de atualização acionado.', xbmc.LOGINFO)
    verificar_versao_e_atualizar()
    xbmcplugin.endOfDirectory(addon_handle)
elif rota == 2:
    database_update(db_host)
    exibir_filmes(cat)
elif rota == 3:
    database_update(db_host)
    categorias_series()
elif rota == 4:
    database_update(db_host)
    exibir_temporadas_series(cat)
elif rota == 5:
    database_update(db_host)
    exibir_episodios_series(cat, season)
elif rota == 6:
    database_update(db_host)
    find()
elif rota == 7:
    database_update(db_host)
    categorias_animes()
elif rota == 8:
    database_update(db_host)
    exibir_temporadas_animes(cat)
elif rota == 9:
    database_update(db_host)
    exibir_episodios_animes(cat, season)
elif rota == 10:
    database_update(db_host)
    categorias_novelas()
elif rota == 11:
    database_update(db_host)
    exibir_temporadas_novelas(cat)
elif rota == 12:
    database_update(db_host)
    exibir_episodios_novelas(cat, season)
elif rota == 13:
    try:
        name = name.split('\\ ')[1]
    except:
        pass
    try:
        name = name.split('  - ')[0]
    except:
        pass
    addFavorite(name, url, fav_mode, subtitle, iconimage, fanart, description, cat, season, play)

elif rota == 14:
    try:
        name = name.split('\\ ')[1]
    except:
        pass
    try:
        name = name.split('  - ')[0]
    except:
        pass
    rmFavorite(name)

elif rota == 15:
    getFavorites()

elif rota == 16:
    xbmc.log("Executando rota 16: limpar minha lista", xbmc.LOGINFO)
    limpar_lista()

elif rota == 17:
    database_update(db_host)
    radios()

elif rota == 18:
    database_clear()
    database_update(db_host)
    notify('Conteúdos verificados!', 'OneX')

elif rota == 19:
    database_update(db_host)
    lancamento_filmes(cat)

elif rota == 20:
    name = params.get("name", "")
    url = params.get("url", "")
    iconimage = params.get("iconimage", "")
    description = params.get("description", "")
    subtitle = params.get("subtitle", "")
    play = params.get("play", "False")
    
    play_video(name, url, iconimage, description, subtitle, play)